// Complete IRC numeric-reply table (per https://modern.ircdocs.horse/).
// Used so every numeric is recognised and presented sensibly — never dumped raw.

const NUMERIC_NAMES: Record<string, string> = {
  '001': 'RPL_WELCOME', '002': 'RPL_YOURHOST', '003': 'RPL_CREATED', '004': 'RPL_MYINFO',
  '005': 'RPL_ISUPPORT', '010': 'RPL_BOUNCE',
  '200': 'RPL_TRACELINK', '201': 'RPL_TRACECONNECTING', '202': 'RPL_TRACEHANDSHAKE',
  '203': 'RPL_TRACEUNKNOWN', '204': 'RPL_TRACEOPERATOR', '205': 'RPL_TRACEUSER',
  '206': 'RPL_TRACESERVER', '208': 'RPL_TRACENEWTYPE', '209': 'RPL_TRACECLASS',
  '211': 'RPL_STATSLINKINFO', '212': 'RPL_STATSCOMMANDS', '219': 'RPL_ENDOFSTATS',
  '221': 'RPL_UMODEIS', '234': 'RPL_SERVLIST', '235': 'RPL_SERVLISTEND',
  '242': 'RPL_STATSUPTIME', '243': 'RPL_STATSOLINE',
  '251': 'RPL_LUSERCLIENT', '252': 'RPL_LUSEROP', '253': 'RPL_LUSERUNKNOWN',
  '254': 'RPL_LUSERCHANNELS', '255': 'RPL_LUSERME', '256': 'RPL_ADMINME',
  '257': 'RPL_ADMINLOC1', '258': 'RPL_ADMINLOC2', '259': 'RPL_ADMINEMAIL',
  '263': 'RPL_TRYAGAIN', '265': 'RPL_LOCALUSERS', '266': 'RPL_GLOBALUSERS',
  '276': 'RPL_WHOISCERTFP', '300': 'RPL_NONE', '301': 'RPL_AWAY', '302': 'RPL_USERHOST',
  '305': 'RPL_UNAWAY', '306': 'RPL_NOWAWAY', '307': 'RPL_WHOISREGNICK',
  '311': 'RPL_WHOISUSER', '312': 'RPL_WHOISSERVER', '313': 'RPL_WHOISOPERATOR',
  '314': 'RPL_WHOWASUSER', '315': 'RPL_ENDOFWHO', '317': 'RPL_WHOISIDLE',
  '318': 'RPL_ENDOFWHOIS', '319': 'RPL_WHOISCHANNELS', '320': 'RPL_WHOISSPECIAL',
  '321': 'RPL_LISTSTART', '322': 'RPL_LIST', '323': 'RPL_LISTEND', '324': 'RPL_CHANNELMODEIS',
  '329': 'RPL_CREATIONTIME', '330': 'RPL_WHOISACCOUNT', '331': 'RPL_NOTOPIC',
  '332': 'RPL_TOPIC', '333': 'RPL_TOPICWHOTIME', '335': 'RPL_WHOISBOT',
  '336': 'RPL_INVITELIST', '337': 'RPL_ENDOFINVITELIST', '338': 'RPL_WHOISACTUALLY',
  '341': 'RPL_INVITING', '346': 'RPL_INVEXLIST', '347': 'RPL_ENDOFINVEXLIST',
  '348': 'RPL_EXCEPTLIST', '349': 'RPL_ENDOFEXCEPTLIST', '351': 'RPL_VERSION',
  '352': 'RPL_WHOREPLY', '353': 'RPL_NAMREPLY', '354': 'RPL_WHOSPCRPL',
  '364': 'RPL_LINKS', '365': 'RPL_ENDOFLINKS', '366': 'RPL_ENDOFNAMES',
  '367': 'RPL_BANLIST', '368': 'RPL_ENDOFBANLIST', '369': 'RPL_ENDOFWHOWAS',
  '371': 'RPL_INFO', '372': 'RPL_MOTD', '374': 'RPL_ENDOFINFO', '375': 'RPL_MOTDSTART',
  '376': 'RPL_ENDOFMOTD', '378': 'RPL_WHOISHOST', '379': 'RPL_WHOISMODES',
  '381': 'RPL_YOUREOPER', '382': 'RPL_REHASHING', '391': 'RPL_TIME', '396': 'RPL_HOSTHIDDEN',
  '400': 'ERR_UNKNOWNERROR', '401': 'ERR_NOSUCHNICK', '402': 'ERR_NOSUCHSERVER',
  '403': 'ERR_NOSUCHCHANNEL', '404': 'ERR_CANNOTSENDTOCHAN', '405': 'ERR_TOOMANYCHANNELS',
  '406': 'ERR_WASNOSUCHNICK', '409': 'ERR_NOORIGIN', '411': 'ERR_NORECIPIENT',
  '412': 'ERR_NOTEXTTOSEND', '417': 'ERR_INPUTTOOLONG', '421': 'ERR_UNKNOWNCOMMAND',
  '422': 'ERR_NOMOTD', '431': 'ERR_NONICKNAMEGIVEN', '432': 'ERR_ERRONEUSNICKNAME',
  '433': 'ERR_NICKNAMEINUSE', '436': 'ERR_NICKCOLLISION', '441': 'ERR_USERNOTINCHANNEL',
  '442': 'ERR_NOTONCHANNEL', '443': 'ERR_USERONCHANNEL', '451': 'ERR_NOTREGISTERED',
  '461': 'ERR_NEEDMOREPARAMS', '462': 'ERR_ALREADYREGISTERED', '464': 'ERR_PASSWDMISMATCH',
  '465': 'ERR_YOUREBANNEDCREEP', '471': 'ERR_CHANNELISFULL', '472': 'ERR_UNKNOWNMODE',
  '473': 'ERR_INVITEONLYCHAN', '474': 'ERR_BANNEDFROMCHAN', '475': 'ERR_BADCHANNELKEY',
  '476': 'ERR_BADCHANMASK', '481': 'ERR_NOPRIVILEGES', '482': 'ERR_CHANOPRIVSNEEDED',
  '483': 'ERR_CANTKILLSERVER', '491': 'ERR_NOOPERHOST', '501': 'ERR_UMODEUNKNOWNFLAG',
  '502': 'ERR_USERSDONTMATCH', '524': 'ERR_HELPNOTFOUND', '525': 'ERR_INVALIDKEY',
  '670': 'RPL_STARTTLS', '671': 'RPL_WHOISSECURE', '691': 'ERR_STARTTLS',
  '696': 'ERR_INVALIDMODEPARAM', '704': 'RPL_HELPSTART', '705': 'RPL_HELPTXT',
  '706': 'RPL_ENDOFHELP', '723': 'ERR_NOPRIVS',
  '730': 'RPL_MONONLINE', '731': 'RPL_MONOFFLINE', '732': 'RPL_MONLIST',
  '733': 'RPL_ENDOFMONLIST', '734': 'ERR_MONLISTFULL', '735': 'RPL_KEYVALUE', '759': 'RPL_ETRACEEND',
  '900': 'RPL_LOGGEDIN', '901': 'RPL_LOGGEDOUT', '902': 'ERR_NICKLOCKED',
  '903': 'RPL_SASLSUCCESS', '904': 'ERR_SASLFAIL', '905': 'ERR_SASLTOOLONG',
  '906': 'ERR_SASLABORTED', '907': 'ERR_SASLALREADY', '908': 'RPL_SASLMECHS',
};

// Numerics that report an error to the user — shown as a prominent error line.
const ERROR_CODES = new Set([
  '400', '401', '402', '403', '404', '405', '406', '409', '411', '412', '417', '421',
  '422', '431', '432', '433', '436', '441', '442', '443', '451', '461', '462', '464',
  '465', '471', '472', '473', '474', '475', '476', '481', '482', '483', '491', '501',
  '502', '524', '525', '691', '696', '723', '734', '902', '904', '905', '906', '907',
]);

// Numeric-reply knowledge as a small collaborator, reached as `client.numerics`.
// Pure protocol data (no connection state, no i18n): it answers "what is code N?"
// and "is it an error?". Friendly per-error text stays a presentation concern —
// resolved in the store handler via the i18n `numerics.<code>` keys, falling back
// to the server's own trailing message when a code isn't translated.
export class Numerics {
  /** The RPL/ERR reply name for a numeric code, or undefined if unknown. */
  name(code: string): string | undefined { return NUMERIC_NAMES[code]; }
  /** True when the code is a user-facing error reply (shown as a ⚠ line). */
  isError(code: string): boolean { return ERROR_CODES.has(code); }
}
